// Including all the needed libraries.

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>

// The CHECK(X) function is usefull to write on shell whenever a system call return an error.
// The function will print the name of the file and the line at which it found the error.
// It will end the check exiting with code 1.

#define CHECK(X) (                                                 \
    {                                                              \
        int __val = (X);                                           \
        (__val == -1 ? (                                           \
                           {                                       \
                               fprintf(stderr, "ERROR ("__FILE__   \
                                               ":%d) -- %s\n",     \
                                       __LINE__, strerror(errno)); \
                               exit(EXIT_FAILURE);                 \
                               -1;                                 \
                           })                                      \
                     : __val);                                     \
    })

int val;

// From the Inspection Console we send Signals in order to STOP / RESET the 
// position of the hoist. Moreover we have to send a Signal from the Command Console,
// simply to stop the motor X (also for motor Z). We have implemented a flag logic, in order to see 
// if we are stopping / resetting the system (or simply stop one motor). 
// All the specific Signals are logically sent from the interested process that manage them.

void handler(int sig){

	if(sig == SIGUSR1){

		// Flag necessary to make the motor x stop

		val = 5;
	}

	if(sig == SIGUSR2){
		
		// Flag necessary to make the motor x decrease its position
		// just for the reset routine 

		val = 2;
	}
}

// Main in which we developed the principal code of the motor x.

int main(int argc, char* argv[]){	

	// declaration of needed variables 
	 
	int fd_from_comm;
	int fd_to_insp;
	int retval;

	// The code to design, develop, test and deploy is an interactive simulator  of hoist with 2 d.o.f, in 
    // which two different consoles allow the user to activate the hoist.
    // In the octagonal box there are two motors mx and mz, which displace the hoist along the two 
    // respective axes. Motions along axes have their bounds, say 0 - max_x and 0 - max_z.

	// defining the x and the step made by the hoist everytime i increase/decrease it.

	double x = 0.0;
	double step = 0.1;

	// Initialize time struct for "fprintf" the exact time in which we do an operation
	// Initialize the struct for Signals

	struct timeval tv;
	struct sigaction sa;

	fd_set rdset;

	// pipes opening for reading from Command Console and writing to Inspection Console the x position 
	
	CHECK(fd_from_comm = open("/tmp/x", O_RDONLY));
	CHECK(fd_to_insp = open("/tmp/inspx", O_WRONLY));
	
	while(1){
		
		// Defining an error to add to the X position (like in reality, we do not have the exact real position)

		double error = (double) rand() /(double) (RAND_MAX/0.001);
		
		// Declaring for the use of Signals.
		
		memset(&sa, 0, sizeof(sa));
		sa.sa_handler=&handler;
		sa.sa_flags=SA_RESTART;
		CHECK(sigaction(SIGUSR1, &sa, NULL));
		CHECK(sigaction(SIGUSR2,&sa,NULL));

		// we want to read instantly the datas from Command Console, not waiting 
	
		tv.tv_sec = 0;
		tv.tv_usec = 0;
		
		// select() allows a program to monitor multiple file descriptors,
        // waiting until one or more of the file descriptors become "ready"
        // for some class of I/O operation (e.g., input possible). A file
        // descriptor is considered ready if it is possible to perform a
        // corresponding I/O operation without blocking.

	    // This macro clears (removes all file descriptors from) set.
        // It should be employed as the first step in initializing a
        // file descriptor set.
		
		FD_ZERO(&rdset);

		// This macro clears (removes all file descriptors from) set.
        // It should be employed as the first step in initializing a
        // file descriptor set.

		FD_SET(fd_from_comm, &rdset);

		// The principal arguments of select() are three "sets" of file
        // descriptors (declared with the type fd_set), which allow the
        // caller to wait for three classes of events on the specified set
        // of file descriptors. Each of the fd_set arguments may be
        // specified as NULL if no file descriptors are to be watched for
        // the corresponding class of events. So thanks to the select() we can
		// handle the flows of datas to be read.

		retval = select(FD_SETSIZE, &rdset, NULL, NULL, &tv);
		
		if (retval == -1){

			perror("select()");
		}
		
	    // select() modifies the contents of the sets according to
        // the rules described below. After calling select(), the
        // FD_ISSET() macro can be used to test if a file descriptor
        // is still present in a set. FD_ISSET() returns nonzero if
        // the file descriptor fd is present in set, and zero if it
        // is not.
		
		else if (retval >= 0){

			if(FD_ISSET(fd_from_comm, &rdset) != 0){

				// Reading datas from Command Console

				CHECK(read(fd_from_comm, &val, sizeof(val)));
			}   
		}
		
		// Thanks to this switch we can now know in which state we are (Flag logic):

		switch(val){
							
		    case 1: 

			// We enter in this case only if it is sent a Signal from the Command Console
			// to increase the motor position.

		    	if(x >= 5){
				
				// Of course we do not nothing if we reach the top boundary

				}
					
				else{
					
					// Else we increase the hoist's x position

					x += step;
					x = x + error;
				}

				// The sleep function is used to simulate the real position's changes, waiting for the engine
				// to terminate them

				CHECK(sleep(1));
		    break;					

		    case 2: 

			// We enter in this case only if were sent Signals for stopping the motor,
			// whether are sent by the Command Console (to stop the single motor) or by the Inspection
			// Console (to stop both motors)

				if (x <= 0){

				// Of course we do not nothing if we reach the bottom boundary

				}
							
				else{
					
					// Else we decrease the hoist's x position

					x -= step;
					x = x + error;
				}

				// The sleep function is used to simulate the real position's changes, waiting for the engine
				// to terminate them

				CHECK(sleep(1));
        	break;
					
	    	case  5:

  			// We enter in this case only if were sent Signals for stopping the motor,
			// whether are sent by the Command Console (to stop the single motor) or by the Inspection
			// Console (to stop both motors)

				CHECK(sleep(1));
		    break;
		}

		// Once we reach the top/bottom boundaries, the x position will update everytime 
		// with same same values:
		// x = 5 --> top boundary's value
		// x = 0 --> top boundary's value

	    if (x > 5.0){

			x = 5.0;
		}
			
	    if (x < 0.0){ 

			x = 0.0;
		}

		// Write the x position to the Inspection that will output it

	    CHECK(write(fd_to_insp, &x, sizeof(x)));
	
	}
	
	// Closing pipes

	CHECK(close(fd_from_comm));
	CHECK(close(fd_to_insp));
	
	return 0;
}

	
