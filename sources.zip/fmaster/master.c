// Including all the needed libraries.

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>

// The CHECK(X) function is usefull to write on shell whenever a system call return an error.
// The function will print the name of the file and the line at which it found the error.
// It will end the check exiting with code 1.

#define CHECK(X) (                                                 \
    {                                                              \
        int __val = (X);                                           \
        (__val == -1 ? (                                           \
                           {                                       \
                               fprintf(stderr, "ERROR ("__FILE__   \
                                               ":%d) -- %s\n",     \
                                       __LINE__, strerror(errno)); \
                               exit(EXIT_FAILURE);                 \
                               -1;                                 \
                           })                                      \
                     : __val);                                     \
    })

// Using fork() and exec() allows the calling program to continue execution in
// the parent process while the calling program is replaced by the subprogram in the child process. 

int spawn(const char * program, char ** arg_list) {

	// When a program calls fork, a duplicate process, called the child process, is created.
	// The parent process continues executing the program from the point that fork was called. The child process, too, executes the same program from the same place.
	// The fork function provides different return values to the parent and child processes
	// one process "goes in" to the fork call, and two processes "come out," with different return values.
	// The return value in the parent process is the process ID of the child.
	// The return value in the child process is zero.
	
	pid_t child_pid = fork();

  	if (child_pid != 0){

    	return child_pid;
    }

  	else {

		// The exec functions replace the program running in a process with another program. 
		// When a program calls an exec function, that process immediately ceases executing that program and begins executing a new program from the beginning, 
		// assuming that the exec call doesn't encounter an error. 

		CHECK(execvp(program, arg_list));
		fprintf (stderr, "An error occurred in execvp\n");
		abort ();
    }
}

// Main in which we developed the principal code of master

int main(){

	// Thanks to these lines of code we can report on the file.txt (logfile.txt) 
	// all the operations we have done. The logfile.txt is created in the master process, in fact
	// there is the append inside the function fopen() that is not "a" like in every other process, but "w"-->
	// Creates an empty file for writing. If a file with the same name already exists, 
	// its content is erased and the file is considered as a new empty file. Whereas in other processes there is the append "a"-->
	// Appends to a file. Writing operations, append data at the end of the file. 
	// The file is created if it does not exist. 
	// We can "concatenate" all the things we do in every single process, reporting them in the logfile.txt, thanks
	// to the "a" append.

	FILE *out = fopen("logfile.txt", "w");
    if(out == NULL){

        printf("Error opening FILE");
    }
	
	fclose(out);

	// Declaring all necessary PIDs

	pid_t pid_comm;
	pid_t pid_m_x;
	pid_t pid_m_z; 
	pid_t pid_insp; 
	pid_t pid_wd;
	pid_t pid_master;

	// Getting the pid's master to "fprintf" it in the log file

	pid_master=getpid();

	// Declaring arrays of char (read after)
	
	char pid_motor_x[20];
	char pid_motor_z[20];
	char pid_watchdog[20];
	
	// Creation of all pipes needed between processes
	
	mkfifo("/tmp/x", 0666);
	mkfifo("/tmp/z", 0666);
	mkfifo("/tmp/inspx", 0666);
	mkfifo("/tmp/inspz", 0666);
	mkfifo("/tmp/cwd", 0666);
	mkfifo("/tmp/cti", 0666);
	
	// Arguments that i have to pass to the process that i want to execute through master's child.
	// The arguments in this arg_list will be read from the main , thanks to its particular declaration in c:
	// In each process--> main(int argc, char *argv[]) --> 
	// argc : contains the number of strings insert in the command line by the user
	// argv : array which contains the strings insert in the command line by the user
	
	char *arg_list_m_x[] = { "./m_x", "/tmp/x", NULL };
	char *arg_list_m_z[] = { "./m_z", "/tmp/z" , NULL };
	
	// fork to create various child processes 
	
	pid_m_x = spawn("./m_x", arg_list_m_x); 
	pid_m_z = spawn("./m_z", arg_list_m_z);

	// We convert the PIDs from integer to string, in order to succesfully 
	// pass it to the arguments of the arg_list

	sprintf(pid_motor_x, "%d", pid_m_x);
	sprintf(pid_motor_z, "%d", pid_m_z);
	
	char *arg_list_watchdog[] = {"./watchdog", "/tmp/cwd", pid_motor_x, pid_motor_z, (char*)NULL };
	pid_wd = spawn("./watchdog", arg_list_watchdog);
	sprintf(pid_watchdog, "%d", pid_wd);
	
	char *arg_list_comm[] = { "/usr/bin/konsole",  "-e", "./command", pid_watchdog, (char*)NULL };
	pid_comm = spawn("/usr/bin/konsole", arg_list_comm);

	char *arg_list_insp[] = { "/usr/bin/konsole",  "-e", "./inspection", "/tmp/cti", pid_motor_x, pid_motor_z, pid_watchdog, (char*)NULL };
	pid_insp = spawn("/usr/bin/konsole", arg_list_insp);

	// We open the same logfile.txt in the master process, in order to write on it the 
	// pid of every process (since the master handles the creation the of the multiple processes, of the pipes and their unlinking)

	FILE *out2 = fopen("logfile.txt", "a");
    if(out2 == NULL){

        printf("Error opening FILE");
    }

	fprintf(out2, "PID ./master: %d\n", pid_master);
  	fprintf(out2, "PID ./motor_x: %d\n", pid_m_x);
  	fprintf(out2, "PID ./motor_z: %d\n", pid_m_z);
  	fprintf(out2, "PID ./watchdog: %d\n", pid_wd);
	fflush(out2);
  	fclose(out2);
	
	// The system call wait() is easy. This function blocks the calling process until one of its child
	// processes exits or a signal is received. For our purpose, we shall ignore signals. 
	// wait() takes the address of an integer variable and returns the process ID of the completed process. 
	// Some flags that indicate the completion status of the child process are passed back with the integer pointer. 
	// One of the main purposes of wait() is to wait for completion of child processes. 

	// So we wait until all the child processes terminate. Then the "father" will terminate, unlinking all the pipes-->
	// The unlink function deletes the file name filename . If this is a file's sole name, 
	// the file itself is also deleted.

	CHECK(wait(NULL));
	
	CHECK(unlink("/tmp/x"));
	CHECK(unlink("/tmp/z"));
	CHECK(unlink("/tmp/inspx"));
	CHECK(unlink("/tmp/inspz"));
	CHECK(unlink("/tmp/cwd"));
	CHECK(unlink("/tmp/cti"));

	// At the end, thanks to the SIGKILL , we will terminate completely the processes.

	CHECK(kill(pid_insp, SIGKILL));
	CHECK(kill(pid_wd, SIGKILL));
	CHECK(kill(pid_m_x, SIGKILL));
	CHECK(kill(pid_m_z, SIGKILL));
	
	return 0;

}
		
