// Including all the needed libraries.

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <termios.h>
#include <time.h>
#include <sys/wait.h>

// Defining some colors

#define BMAG "\e[1;35m"
#define BHBLU "\e[1;94m" 
#define RED "\033[31m"
#define RESET "\033[0m" 

// The CHECK(X) function is usefull to write on shell whenever a system call return an error.
// The function will print the name of the file and the line at which it found the error.
// It will end the check exiting with code 1.

#define CHECK(X) (                                                 \
    {                                                              \
        int __val = (X);                                           \
        (__val == -1 ? (                                           \
                           {                                       \
                               fprintf(stderr, "ERROR ("__FILE__   \
                                               ":%d) -- %s\n",     \
                                       __LINE__, strerror(errno)); \
                               exit(EXIT_FAILURE);                 \
                               -1;                                 \
                           })                                      \
                     : __val);                                     \
    })

// Main in which we developed the principal code of the command console.

int main(int argc, char* argv[]){

	// Thanks to these lines of code we can report on the file.txt (logfile.txt) 
	// all the operations we have done. The logfile.txt is created in the master process, in fact
	// there is the append inside the function fopen() that is not "a" like in every other process, but "w"-->
	// Creates an empty file for writing. If a file with the same name already exists, 
	// its content is erased and the file is considered as a new empty file. Whereas in other processes there is the append "a"-->
	// Appends to a file. Writing operations, append data at the end of the file. 
	// The file is created if it does not exist. 
	// We can "concatenate" all the things we do in every single process, reporting them in the logfile.txt, thanks
	// to the "a" append.

	FILE *out = fopen("logfile.txt", "a");
 
 	if(out == NULL){
        printf("Error opening FILE");
    }

	// We "report" on the logfile the process id of the command console

	fprintf(out, "PID ./inspection: %d\n", getpid()); fflush(out);

	// // Just some aesthetic stuffs.

	printf(BHBLU "I  N    N  SSSS  PPPP   EEEE  CCCCC  TTTTT  I  OOOO  N    N" RESET "\n");           
	printf(BHBLU "I  N N  N  S     P   P  E     C        T    I  O  O  N N  N" RESET "\n");
    printf(BHBLU "I  N  N N   S    PPPP   EEEE  C        T    I  O  O  N  N N" RESET "\n");
    printf(BHBLU "I  N    N     S  P      E     C        T    I  O  O  N    N" RESET "\n");
	printf(BHBLU "I  N    N  SSSS  P      EEEE  CCCCC    T    I  OOOO  N    N" RESET "\n");
	printf("\n");
	printf("\n");
	printf(BMAG "This is the Inspection Console, please press:" RESET "\n");
	printf(BMAG "Q : to STOP the hoist." RESET "\n");
	printf(BMAG "R : to RESET its position (to 0)" RESET "\n");

	// We had put this structure code just to avoid pressing 
	// "Enter" every time we want to increase/decrease x and z of our joist
	// The tcgetattr() function will get the parameters associated with 
    // the terminal referred to by the first argument and store them in 
    // the termios structure referenced by the second argument.

	static struct termios oldt;

	void restore_terminal_settings(void){

		tcsetattr(0, TCSANOW, &oldt);  // Apply saved settings 
	}

	void disable_waiting_for_enter(void){

		struct termios newt;

		// Make terminal read 1 char at a time 
		tcgetattr(0, &oldt);  // Save terminal settings 
		newt = oldt;  // Init new settings 
		newt.c_lflag &= ~(ICANON | ECHO);  // Change settings 
		tcsetattr(0, TCSANOW, &newt);  // Apply settings 
		atexit(restore_terminal_settings); // Make sure settings will be restored when program ends  
	}

	// Setting the current time. This is very usefull since we can report on the logfile.txt the 
	// exact time we have done a particular operation

	time_t current_time;
    struct timeval tv={0,0};

	disable_waiting_for_enter();

	// declaration of needed variables 
	
	char ch;

	// Declaring PIDs used for sending Signals

	pid_t pid_motor_x;
	pid_t pid_motor_z;
	pid_t pid_wd;
	pid_t pid_command;

	double x;
	double z;
	
	// Declaring int for pipes.

	int fd_from_mx;
	int fd_from_mz;
	int fd_from_comm;
	int retval;
	int waiting = 0;
 
	fd_set rdset;
	
	// pipes opening 
	
	fd_from_mx = open("/tmp/inspx", O_RDONLY);
	fd_from_mz = open("/tmp/inspz", O_RDONLY);
	fd_from_comm = open("/tmp/cti", O_RDONLY);
	
	// We convert the watchdog's pid thanks to atoi--> from string to integer
	// argv[2/3/4] are the third/fourth/fifth arguments passed to the main from the master process (see master process
	// for detailed explenation) 
	
	pid_motor_x = atoi(argv[2]);
	pid_motor_z = atoi(argv[3]);
	pid_wd = atoi(argv[4]);

	// read the pid command in the Inspection console to send Signal to the Command Console

	CHECK(read(fd_from_comm, &pid_command, sizeof(pid_command)));

	while(1){
		
		time(&current_time);

		// select() allows a program to monitor multiple file descriptors,
        // waiting until one or more of the file descriptors become "ready"
        // for some class of I/O operation (e.g., input possible). A file
        // descriptor is considered ready if it is possible to perform a
        // corresponding I/O operation without blocking.

	    // This macro clears (removes all file descriptors from) set.
        // It should be employed as the first step in initializing a
        // file descriptor set.

        FD_ZERO(&rdset);

		// This macro clears (removes all file descriptors from) set.
        // It should be employed as the first step in initializing a
        // file descriptor set.
		
		FD_SET(fd_from_mx, &rdset);
		FD_SET(fd_from_mz, &rdset);
		FD_SET(0,&rdset);
		
		// we want to read instantly the datas from motors 
	
		tv.tv_sec = 0;
		tv.tv_usec = 0;

		// The principal arguments of select() are three "sets" of file
        // descriptors (declared with the type fd_set), which allow the
        // caller to wait for three classes of events on the specified set
        // of file descriptors. Each of the fd_set arguments may be
        // specified as NULL if no file descriptors are to be watched for
        // the corresponding class of events. So thanks to the select() we can
		// handle the flows of datas to be read.
		
		retval = select(FD_SETSIZE, &rdset, NULL, NULL, &tv);
		
		if (retval == -1){

			perror("select()");
		}
		
		// select() modifies the contents of the sets according to
        // the rules described below. After calling select(), the
        // FD_ISSET() macro can be used to test if a file descriptor
        // is still present in a set. FD_ISSET() returns nonzero if
        // the file descriptor fd is present in set, and zero if it
        // is not.

		else if (retval >= 0){
			
			if(FD_ISSET(fd_from_mx, &rdset) != 0){

				// reading datas directly from motors

				read(fd_from_mx, &x, sizeof(x));
			}
			
			if(FD_ISSET(fd_from_mz, &rdset) != 0){

				read(fd_from_mz, &z, sizeof(z));
			}
		}
		
		if (FD_ISSET(0,&rdset)>0){
			CHECK(read(0, &ch, sizeof(char)));
		
			// we now handle the Emergency Buttons

			if(ch == 'q'){
				
				printf(RED "\nEMERGENCY STOP PRESSED!" RESET "\n");
				fprintf(out, "Emergency stop pressed!     Time:  %s", ctime(&current_time));
                fflush(out);

				// Whenever is pressed the q button, the system will stop its operation. This 
				// emergency button is strictly related to the STOP operation that is done in the 
				// motors. In fact we send a Signal to the motors that will make activate the STOP
				// made in each motor. Moreover, since we pressed a button, that is q, we will send also a Signal
				// to the watchdog that will restart the alarm() counter; indeed if not button is pressed,
				// the counter will go to 0 and the watchdog will make the motor reset.
				// IMPORTANT : if we press the q (STOP) button, we will send a Signal also to the Command Console:
				// In general, if we are in the RESET condition, the Command Console will be disabled--> BUT if we press q (EMERGENCY
				// STOP) the hoist will STOP and the Command Console will be rehabilitated. This is the safest way in case we have to stop
				// the machine during the RESET routine. We have managed it thanks to the Signals.

				CHECK(kill(pid_wd, SIGUSR1));
				CHECK(kill(pid_motor_x, SIGUSR1));
				CHECK(kill(pid_motor_z, SIGUSR1));
				CHECK(kill(pid_command, SIGUSR1));
			
				fflush(stdout);
			}

			if(ch == 'r'){

				// Whenever is pressed the r button, the system will reset immediately its position. This 
				// emergency button is strictly related to the RESET operation that is done in the 
				// motors. In fact we send a Signal to the motors that will make activate the RESET routine
				// made in each motor. Moreover, since we pressed a button, that is q, we will send also a Signal
				// to the watchdog that will restart the alarm() counter; indeed if not button is pressed,
				// the counter will go to 0 and the watchdog will make the motor reset.

				printf(RED "\nEMERGENCY RESET PRESSED!" RESET "\n");
				fprintf(out, "Emergency reset pressed!     Time:  %s", ctime(&current_time));
                fflush(out);

				CHECK(kill(pid_wd, SIGUSR1));
				CHECK(kill(pid_motor_x,SIGUSR2));
				CHECK(kill(pid_motor_z,SIGUSR2));
				CHECK(kill(pid_command,SIGUSR2));
		
				fflush(stdout);
			}
		}
		
		// If the reset is completed, the Command Console will be able to work again. All these instructions
		// are handled by the "l" flag at the beginning of the command.c

		if (x == 0 && z == 0){

			kill(pid_command, SIGUSR1);	
		}
		
		printf("\rX position: %f meter, Z position: %f meter", x, z);
		fflush(stdout);

		// The flow of datas "printed" on the logfile.txt is extremely big. So we can reduce it using this
		// waiting variable

		if(waiting%50000==0){ 
			
			fprintf(out, "Position x: %f, Position z: %f     Time:  %s", x, z, ctime(&current_time));
			fflush(out);
		}
  		waiting++;
		
	}
	
	CHECK(fclose(out));
	
	// Closing pipes

	CHECK(close(fd_from_mx));
	CHECK(close(fd_from_mz));
	CHECK(close(fd_from_comm));
	
	return 0;
}
	
	
