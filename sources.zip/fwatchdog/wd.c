// Including all the needed libraries.

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <termios.h>
#include <time.h>
#include <sys/wait.h>

// The CHECK(X) function is usefull to write on shell whenever a system call return an error.
// The function will print the name of the file and the line at which it found the error.
// It will end the check exiting with code 1.

#define CHECK(X) (                                                 \
    {                                                              \
        int __val = (X);                                           \
        (__val == -1 ? (                                           \
                           {                                       \
                               fprintf(stderr, "ERROR ("__FILE__   \
                                               ":%d) -- %s\n",     \
                                       __LINE__, strerror(errno)); \
                               exit(EXIT_FAILURE);                 \
                               -1;                                 \
                           })                                      \
                     : __val);                                     \
    })

// Declaring PIDs of each process, used for Signals

pid_t pid_m_x;
pid_t pid_m_z;
pid_t pid_command;

// Declaring the pipe

int fd_c_to_wd;

// In this section of the code we handle Signals coming directly from Command Console
// and Inspection Console. Everytime we press a button (X increase/decrease/stop - Z increase/decrease/stop -
// Emergency Stop Button - Emergency Reset Button) we send a Signal to the watchdog that will
// make the alarm() counter restart. This counter is needed in order to disable the Command Console
// and reset the hoist's positions after 60 seconds (of inactivity)

void handler(int sig){

	if(sig == SIGUSR1){

		alarm(60);
	}
	
	// This SIGALRM is directly sent by the watchdog process itself. In case we do not
	// press any button, since the opening of the Command and Inspection Console, the alarm counter put
	// in the main will go to 0. After that the SIGALRM will be sent and, through Signals
	// we will: 1) Make motor x reset 2) Make motor z reset 3) Disable the Command Console

	if(sig == SIGALRM){

		kill(pid_m_x, SIGUSR2);
		kill(pid_m_z, SIGUSR2);
		kill(pid_command, SIGUSR2);
	}
}

// Main in which we developed the principal code of watchdog

int main(int argc, char * argv[]){

	// Opening the pipes

	// argv[1] is the second argument passed to the main from the master process (see master process
	// for detailed explenation) 

	CHECK(fd_c_to_wd=open(argv[1], O_RDONLY));

	// We convert the motors' pid thanks to atoi--> from string to integer
	// argv[2/3] are the third/fourth arguments passed to the main from the master process (see master process
	// for detailed explenation) 

	pid_m_x = atoi(argv[2]);
	pid_m_z = atoi(argv[3]);

	// Declaring for the use of Signals. 
	
	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler=&handler;
	sa.sa_flags=SA_RESTART;

	// If no button is pressed since the opening of the Consoles, the alarm will go
	// to 0;
	
	alarm(60);
	
	CHECK(sigaction(SIGUSR1, &sa, NULL));
	CHECK(sigaction(SIGALRM,&sa,NULL));

	// Read the pid of commmand.c
	
	CHECK(read(fd_c_to_wd, &pid_command, sizeof(pid_command)));
	
	// 

	while(1){
		
		sleep(1);
	}

	// closing pipe

	CHECK(close(fd_c_to_wd));

	return 0;
}
