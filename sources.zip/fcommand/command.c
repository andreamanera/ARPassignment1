// Including all the needed libraries.

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>  
#include <signal.h>
#include <string.h>
#include <termios.h>
#include <time.h>
#include <sys/wait.h>

// Defining some colors.

#define BGRN "\e[1;32m"
#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW  "\033[33m"  
#define BLUE "\033[34m"
#define MAGENTA "\033[35m"       
#define CYAN "\033[36m"   
#define WHITE "\033[37m"  
#define RESET "\033[0m" 
#define BHBLU "\e[1;94m"   
#define UYEL "\e[4;33m" 

// The CHECK(X) function is usefull to write on shell whenever a system call return an error.
// The function will print the name of the file and the line at which it found the error.
// It will end the check exiting with code 1.

#define CHECK(X) (                                                 \
    {                                                              \
        int __val = (X);                                           \
        (__val == -1 ? (                                           \
                           {                                       \
                               fprintf(stderr, "ERROR ("__FILE__   \
                                               ":%d) -- %s\n",     \
                                       __LINE__, strerror(errno)); \
                               exit(EXIT_FAILURE);                 \
                               -1;                                 \
                           })                                      \
                     : __val);                                     \
    })

// In this part of the code we use the handler() function in order
// to handle Signals coming from different processes. Like so we can disable
// the Command Console during the reset procedure and restart it once it finished the 
// reset routine. 

int l = 0;

void handler(int sig){

	if(sig == SIGUSR2){
		
		// System is resetting

		l = 1;
		printf(RED "\nSYSTEM RESETTING!" RESET "\n");
	}

	if(sig == SIGUSR1){

		// System able to work again

		l = 0;
	}
}

// Main in which we developed the principal code of the Command Console.

int main(int argc, char *argv[]){

	// Thanks to these lines of code we can report on the file.txt (logfile.txt) 
	// all the operations we have done. The logfile.txt is created in the master process, in fact
	// there is the append inside the function fopen() that is not "a" like in every other process, but "w"-->
	// Creates an empty file for writing. If a file with the same name already exists, 
	// its content is erased and the file is considered as a new empty file. Whereas in other processes there is the append "a"-->
	// Appends to a file. Writing operations, append data at the end of the file. 
	// The file is created if it does not exist. 
	// We can "concatenate" all the things we do in every single process, reporting them in the logfile.txt, thanks
	// to the "a" append.

	FILE *out = fopen("logfile.txt", "a");
 
 	if(out == NULL){
		 
        printf("Error opening FILE");
    }

	// We "report" on the logfile the process id of the Command Console

	fprintf(out, "PID ./command: %d\n", getpid()); fflush(out);
	
	// We had put this structure code just to avoid pressing 
	// "Enter" every time we want to increase/decrease x and z of our joist
	// The tcgetattr() function will get the parameters associated with 
    // the terminal referred to by the first argument and store them in 
    // the termios structure referenced by the second argument.

	static struct termios oldt;

	void restore_terminal_settings(void){

		tcsetattr(0, TCSANOW, &oldt);  // Apply saved settings. 
	}

	void disable_waiting_for_enter(void){

		struct termios newt;

		// Make terminal read 1 char at a time.

		tcgetattr(0, &oldt);  
		newt = oldt;  
		newt.c_lflag &= ~(ICANON | ECHO); 
		tcsetattr(0, TCSANOW, &newt);  
		atexit(restore_terminal_settings);  
	}


	// Setting the current time. This is very usefull since we can report on the logfile.txt the 
	// exact time we have done a particular operation

	time_t current_time;
    struct timeval tv={0,0};
     
	// Just some aesthetic stuffs.

	printf(BHBLU "CCCC  OOOO  M     M  M     M     A     N    N  DD   " RESET "\n");           
	printf(BHBLU "C     O  O  M M M M  M M M M    A A    N N  N  D D  " RESET "\n");
    printf(BHBLU "C     O  O  M  M  M  M  M  M   AAAAA   N  N N  D  D " RESET "\n");
    printf(BHBLU "CCCC  OOOO  M     M  M     M  A     A  N    N  DDDD " RESET "\n");
	printf("\n");
	printf("\n");
    printf(BGRN "This is a robot simulator, developed directly by Lorenzo Benedetti and Andrea Manera\n");
	printf(BGRN "The worker can directly move the hoist using the following commands:\n" );
	printf("\n");
    printf(UYEL "To move UP, please press W" RESET "\n");
    printf(UYEL "To move DOWN, please press S" RESET "\n");
    printf(UYEL "To move RIGHT, please press D" RESET "\n");
    printf(UYEL "To move LEFT, please press A" RESET "\n");
    printf(UYEL "To STOP z axis, please press Z" RESET "\n");
    printf(UYEL "To STOP x axis, please press X" RESET "\n");
	printf(UYEL "Press E if you want to terminate programs execution" RESET "\n");
    printf("\n");
	
    disable_waiting_for_enter();
    
	// In this part we have declared some varibales usefull in the code.

	// Declaring int for pipes.

    int fd_to_mx;
    int fd_to_mz;
    int fd_to_wd;
	int fd_to_insp;

	// Declaring variables used for select().

    int d = 1;
    int a = 2;
    int w = 3;
    int s = 4;
    int x = 5;
    int z = 6;
    
	// Declaring pid of watchdog and command.

    pid_t pid_wd;
    pid_t pid_command;
    
    char ch;
    
	// Declaring for the use of Signals.

    struct sigaction sa; 
    
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler=&handler;
    sa.sa_flags=SA_RESTART;
    CHECK(sigaction(SIGUSR2, &sa, NULL));
	CHECK(sigaction(SIGUSR1, &sa, NULL));

	// We convert the watchdog's pid thanks to atoi--> from string to integer
	// argv[1] is the second argument passed to the main from the master process (see master process
	// for detailed explenation)
    
    pid_wd = atoi(argv[1]);

	// Getting pid of the command, sending it to watchdog and inspection
	// just for using Signals.

    CHECK(pid_command = getpid());
    
    // opens pipes to write the commands 
    
    CHECK(fd_to_mx = open("/tmp/x", O_WRONLY));
    CHECK(fd_to_mz = open("/tmp/z", O_WRONLY));
    CHECK(fd_to_wd = open("/tmp/cwd", O_WRONLY));
	CHECK(fd_to_insp = open("/tmp/cti", O_WRONLY));

	// Writing command pid to watchdog and inspection

    CHECK(write(fd_to_wd, &pid_command, sizeof(pid_command)));
	CHECK(write(fd_to_insp, &pid_command, sizeof(pid_command)));

	// Key reading loop: entering the loop of putting char from keyboard, without exit from program (no return in infinite while loop) 
	
	while ((ch = getchar()) != 'e'){

		// Function getchar() to get the button pressed on the keyboard
		// If "e" is pressed, we exit while loop and the program terminate successfully.
		// Then master kills other processes
		
		// Through the use of "l" we can understand in which state we are.
		// if we are in the reset state (case 1), the system is resetting and no command can be
		// insert, except for the q command---> stop command (in case we have to stop the system in an EMERGENCY
		// during the resetting routine), until the reset has terminated. Indeed in case 0 we are in the normal situation in which 
		// we can use the Command Console, checking through a switch() which button we have entered on the keyboard.

		time(&current_time);

		switch(l){
		
			case 1:
				printf("\n" RED "WAIT, COMMAND CONSOLE DISABLED!" RESET "\n");
				fflush(stdout);
	        break;
	        
			// In the case 0 (normal situation) beyond printing some stuffs, we send a Signal
			// to the watchdog (VERY IMPORTANT) in orhter to reset the timer of the alarm, thanks to
			// after 60 seconds the command console will be disabled.

			case 0:

				
	        	switch(ch){

				    case 119: // case w
						printf(GREEN "Z INCREASE" RESET "\n");
						fflush(stdout);
						fprintf(out, "Z INCREASED     Time:  %s", ctime(&current_time));
                        fflush(out);
						CHECK(write(fd_to_mz, &w, sizeof(ch)));
						CHECK(kill(pid_wd, SIGUSR1));
				    break;

				    case 115: // case s
						printf(RED "Z DECREASE" RESET "\n");
						fflush(stdout);
						fprintf(out, "Z DECREASED     Time:  %s", ctime(&current_time));
                        fflush(out);
						CHECK(write(fd_to_mz, &s, sizeof(ch)));
						CHECK(kill(pid_wd, SIGUSR1));
						
				    break;

				    case 122 :// case z
						printf(CYAN "Z STOP" RESET "\n");
						fflush(stdout);
						fprintf(out, "Z STOPPED     Time:  %s", ctime(&current_time));
                        fflush(out);
						CHECK(write(fd_to_mz, &z, sizeof(ch)));
						CHECK(kill(pid_wd, SIGUSR1));
				    break;
						
				    case 100: // case d
						printf(WHITE "X INCREASE" RESET "\n");
						fflush(stdout);
						fprintf(out, "X INCREASED     Time:  %s", ctime(&current_time));
                        fflush(out);
						CHECK(write(fd_to_mx, &d, sizeof(ch)));
						CHECK(kill(pid_wd, SIGUSR1));
				    break;

				    case 97: // case a
						printf(MAGENTA "X DECREASE" RESET "\n");
						fflush(stdout);
						fprintf(out, "X DECREASED     Time:  %s", ctime(&current_time));
                        fflush(out);
						CHECK(write(fd_to_mx, &a, sizeof(ch)));
						kill(pid_wd, SIGUSR1);
						
				    break;

				    case 120: // case x
						printf(BLUE "X STOP" RESET "\n");
						fflush(stdout);
						fprintf(out, "X STOPPED     Time:  %s", ctime(&current_time));
                        fflush(out);
						CHECK(write(fd_to_mx, &x, sizeof(ch)));
						CHECK(kill(pid_wd, SIGUSR1));
				    break;
					
					// If we press a button different from the previous one, the system will make us notice that

					default: 
						printf(RED "Wrong command!" RESET "\n");
						fprintf(out, "Wrong command pressed!     Time:  %s", ctime(&current_time));
                        fflush(out);
				    break;
				}
			break;
		}
	}

	CHECK(fclose(out));
	// Closing pipes

	CHECK(close(fd_to_mx));
	CHECK(close(fd_to_mz));
	CHECK(close(fd_to_wd));
	CHECK(close(fd_to_insp));

	return 0;
}
